# This class stores the episodes, all the states that come in between the initial state and the terminal state. 
# This is later used by the agent for learning by experience, called "exploration". 

import numpy as np

class GameExperience(object):
    
    # model = neural network model
    # max_memory = number of episodes to keep in memory. The oldest episode is deleted to make room for a new episode.
    # discount = discount factor; determines the importance of future rewards vs. immediate rewards
    
    def __init__(self, model, max_memory=100, discount=0.95):
        self.model = model
        self.max_memory = max_memory
        self.discount = discount
        self.memory = list()
        self.num_actions = model.output_shape[-1]
    
    # Stores episodes in memory
    
    def remember(self, episode):
        # episode = [envstate, action, reward, envstate_next, game_over, valid_actions_next]
        # memory[i] = episode
        # envstate == flattened 1d maze cells info, including pirate cell (see method: observe)
        self.memory.append(episode)
        if len(self.memory) > self.max_memory:
            del self.memory[0]

    # Predicts the next action based on the current environment state        
    def predict(self, envstate):
        return self.model(envstate, training=False).numpy()[0]

    # Returns input and targets from memory, defaults to data size of 10
    def get_data(self, data_size=10):
        env_size = self.memory[0][0].shape[1]   # envstate 1d size (1st element of episode)
        mem_size = len(self.memory)
        data_size = min(mem_size, data_size)
        inputs = np.zeros((data_size, env_size))
        targets = np.zeros((data_size, self.num_actions))
        sample_indices = np.random.choice(mem_size, data_size, replace=False)
        envstates = np.vstack([self.memory[j][0] for j in sample_indices])
        envstates_next = np.vstack([self.memory[j][3] for j in sample_indices])
        current_q = self.model(envstates, training=False).numpy()
        next_q = self.model(envstates_next, training=False).numpy()

        for i, j in enumerate(sample_indices):
            episode = self.memory[j]
            if len(episode) == 6:
                envstate, action, reward, envstate_next, game_over, valid_actions_next = episode
            else:
                envstate, action, reward, envstate_next, game_over = episode
                valid_actions_next = range(self.num_actions)
            inputs[i] = envstate
            # There should be no target values for actions not taken.
            targets[i] = current_q[i]
            # Q_sa = derived policy = max quality env/action = max_a' Q(s', a')
            Q_sa = np.max(next_q[i, list(valid_actions_next)])
            if game_over:
                targets[i, action] = reward
            else:
                # reward + gamma * max_a' Q(s', a')
                targets[i, action] = reward + self.discount * Q_sa
        return inputs, targets
