package com.ben.weighttracker.ui;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;

import com.ben.weighttracker.R;
import com.ben.weighttracker.data.User;
import com.ben.weighttracker.vm.AuthViewModel;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

import java.util.regex.Pattern;

public class LoginActivity extends AppCompatActivity {
    private AuthViewModel authVM;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        authVM = new ViewModelProvider(this).get(AuthViewModel.class);

        TextInputLayout tilUser = findViewById(R.id.tilUsername);
        TextInputLayout tilPass = findViewById(R.id.tilPassword);
        TextInputLayout tilPhone = findViewById(R.id.tilPhone);
        TextInputLayout tilGoal = findViewById(R.id.tilGoal);

        TextInputEditText etUser = findViewById(R.id.etUsername);
        TextInputEditText etPass = findViewById(R.id.etPassword);
        TextInputEditText etPhone = findViewById(R.id.etPhone);
        TextInputEditText etGoal  = findViewById(R.id.etGoal);
        CheckBox cbRegister = findViewById(R.id.cbRegister);
        Button btn = findViewById(R.id.btnGo);

        cbRegister.setOnCheckedChangeListener((b, checked) -> {
            tilPhone.setVisibility(checked ? View.VISIBLE : View.GONE);
            tilGoal.setVisibility(checked ? View.VISIBLE : View.GONE);
            btn.setText(checked ? R.string.register : R.string.login);
            // Clear errors when switching
            tilUser.setError(null);
            tilPass.setError(null);
            tilPhone.setError(null);
            tilGoal.setError(null);
        });

        btn.setOnClickListener(v -> {
            String u = etUser.getText().toString().trim();
            String p = etPass.getText().toString();
            boolean isRegister = cbRegister.isChecked();

            boolean isValid = true;

            // Username validation
            if (TextUtils.isEmpty(u)) {
                tilUser.setError("Username is required");
                isValid = false;
            } else {
                tilUser.setError(null);
            }

            // Password validation (8 chars + 1 special symbol)
            if (p.length() < 8) {
                tilPass.setError("Password must be at least 8 characters long");
                isValid = false;
            } else if (!Pattern.compile("[^a-zA-Z0-9]").matcher(p).find()) {
                tilPass.setError("Password must include at least one special symbol");
                isValid = false;
            } else {
                tilPass.setError(null);
            }

            String phone = etPhone.getText().toString().trim();
            Float goal = null;

            if (isRegister) {
                // Phone validation (10 digits)
                if (phone.length() != 10 || !phone.matches("\\d+")) {
                    tilPhone.setError("Phone must be exactly 10 digits");
                    isValid = false;
                } else {
                    tilPhone.setError(null);
                }

                // Goal weight validation (0-1000)
                String gs = etGoal.getText().toString().trim();
                if (!TextUtils.isEmpty(gs)) {
                    try {
                        goal = Float.parseFloat(gs);
                        if (goal < 0 || goal > 1000) {
                            tilGoal.setError("Goal must be between 0 and 1000");
                            isValid = false;
                        } else {
                            tilGoal.setError(null);
                        }
                    } catch (NumberFormatException e) {
                        tilGoal.setError("Invalid number");
                        isValid = false;
                    }
                } else {
                    tilGoal.setError(null);
                }
            }

            if (!isValid) return;

            try {
                User user;
                if (isRegister) {
                    user = authVM.register(u, p, phone, goal);
                } else {
                    user = authVM.login(u, p);
                    if (user == null) {
                        tilPass.setError("Invalid credentials");
                        return;
                    }
                }
                Intent i = new Intent(this, MainActivity.class);
                i.putExtra("userId", user.id);
                startActivity(i);
                finish();
            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_LONG).show();
            }
        });
    }
}
